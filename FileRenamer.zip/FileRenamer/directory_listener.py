import time

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, PatternMatchingEventHandler
import rename_with_creation_date as rename
from configparser import ConfigParser


class ChangeHandler(PatternMatchingEventHandler):
    try:
        def on_modified(self, event):
            time.sleep(10)
            print(f'event type: {event.event_type} path : {event.src_path}')
            rename.rename(event.src_path)

        def on_created(self, event):
            time.sleep(10)
            print(f'event type: {event.event_type} path : {event.src_path}')
            rename.rename(event.src_path)
    except FileNotFoundError:
        pass
    # def on_closed(self, event):
    #    time.sleep(10)
    #    print(f'event type: {event.event_type} path : {event.src_path}')
    #    rename.rename(event.src_path.replace('~$', ''))


def observeDirectory():
    event_handler = ChangeHandler(ignore_directories=True)
    observer = Observer()
    dir_name = config_reader().split(',')
    observers = []

    for observed_dir in dir_name:
        # Schedules watching of a given path
        observer.schedule(event_handler, observed_dir, recursive=True)
        # Add observable to list of observers
        observers.append(observer)
        # start observer
    observer.start()

    try:
        while True:
            # poll every second
            time.sleep(1)
    except KeyboardInterrupt:
        for o in observers:
            o.unschedule_all()
            # stop observer if interrupted
            o.stop()
    for o in observers:
        # Wait until the thread terminates before exit
        o.join()


def config_reader():
    file = 'ignoredFiletypes.ini'
    config = ConfigParser()
    config.read(file)
    return config['PATH']['pathname']


if __name__ == '__main__':
    observeDirectory()
